# 📦 Handoff pack — index

This folder is the portable package for starting the build in a **new session**.

## Files

| File | What it is |
|---|---|
| **HANDOFF.md** | The master build brief: constraints, recommended builds, full specs for the top 3, template for any other idea, €0 stack, conventions, do-nots. **Start here.** |
| **kickoff-prompt.md** | Paste-ready prompts for the new session: per-idea variants (A1–A5), a "help me choose" version (B), a no-files-attached fallback (C), and quick variants for five more ideas (D). |
| `../ideas.html` | The full catalog — 216 live ideas, descriptions, 12 deep dives, parked list, €0 stack, licensing policy. Searchable. |
| `../master-bank-v1-zero-budget.md` | The zero-budget master bank in markdown (filtered list + parked table + stack). |
| `../guitar-app-ideas.md` | Research: apps, websites, tools, hardware (ideas 1–170). |
| `../part3-plugins.md` | Research: plugin landscape (171–207). |
| `../part4-plugins-deep.md` | Research: deep plugin map — 27 categories, corrections, ideas 208–231. |
| `../ai-crosscheck-prompts.md` | Optional: prompts to cross-check ideas with other AI models. |

## How to start the new session (2 steps)

1. In the new session, attach or paste: **`HANDOFF.md`** and **`ideas.html`** (the other files are there if the session wants depth).
2. Paste **one prompt** from `kickoff-prompt.md` — e.g. A1 for the repair wizard, or B if you want the session to help you choose first.

If the new session can't take attachments, use prompt **C** (the mini-brief) and paste the section of `ideas.html` for your chosen idea.

## Recommended order (if you haven't picked)

1. **#131 Repair Diagnostic Wizard** — fastest to something real (1–2 weeks, pure content + logic).
2. **#27 Public-Domain Songbook Generator** — builds a compounding library asset.
3. **#89 Generated Backing Tracks** — the flagship; most useful day-to-day.
4. **#219 AI-Tab Fidelity Checker** / **#194 Guitar→Tab** — if you want the AI-transcription space.

## The one-line rule for the whole pack

**€0 to build, personal use, local-first, your music is your business.** Everything in this folder respects that.
