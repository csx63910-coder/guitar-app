# 🎸 HANDOFF — Build Brief for a New Session

**What this is:** everything a fresh session (any AI, any developer, any future you) needs to start building one of the guitar software ideas — without having read the four research passes that produced them.

**The situation in one paragraph.** A solo builder wants to build guitar software for **personal use** with **€0 budget**. Out of 236 researched ideas, 216 survived the filter (20 are parked because they need money — hardware, escrow, printing, licensing fees). The goal of the new session: pick one idea and build a working MVP using only free, open-source, local-first tools. No servers required, no paid APIs, no Apple developer accounts, no piracy.

**Two steps to start a new session:**
1. Attach (or paste) these files: `ideas.html`, this `HANDOFF.md`, and `kickoff-prompt.md`.
2. Paste one of the kickoff prompts from `kickoff-prompt.md` (there's a variant for each top pick, and a "help me choose" version).

---

## 1. Hard constraints (non-negotiable)

| Constraint | Meaning |
|---|---|
| **€0 budget** | Free tools, free tiers, open source only. No paid APIs, no GPU rental, no hardware purchases, no domains, no app-store fees. Everything must build AND launch at zero cost. |
| **Personal use** | Built for the owner, not for sale (money may come later, but never as a prerequisite). Tools may be freeware marked "free for personal use". |
| **Any music allowed** | Personal builds have no content restriction — point tools at any music files the owner has. The only line: if a project ever goes to other people, its bundled content must be own/PD/CC/crowd-sourced/user-supplied. |
| **No piracy** | Cracked software, keygens, expired trials as a build base: never — malware risk is real and every needed tool is free legitimately. |
| **Local-first** | Heavy processing on the user's machine (browser or desktop). This is what keeps marginal cost at €0 and makes the free tier sustainable forever. |
| **Plugin extra-rules** | If the pick is a plugin: iPlug2 (MIT) or DPF (ISC), VST3 + CLAP + LV2, no AAX, no iLok, CPU inference only (NAM nano/feather), free capture training via TONE3000. |

## 2. The catalog at a glance

- **216 live ideas** across: Practice (1–26), Tabs & notation (27–48), Ear & rhythm (49–62), Tone & gear (63–84), Songwriting (85–100), Backing tracks (89–90), Jamming & bands (101–116), Teaching B2B (117–130), Luthiers & collectors (131–146), Social (147–158, 163), Plugins (64, 171–231), Trust & standards (169–230), Constraint-born (232–236).
- **20 parked** — blocked by money only: hardware (#159–164), escrow/legal infra (#46/47, #203), print boxes (#167/168), GPU (#228), licensed content plays (#91, #121, #141/142), money stakes (#157), hex hardware (#208/217).
- **Full descriptions:** `ideas.html` (searchable, includes 12 deep dives, the parked list, the €0 stack, and the licensing policy).
- **Research originals:** `guitar-app-ideas.md` (apps/websites 1–170), `part3-plugins.md` + `part4-plugins-deep.md` (plugins 171–231).

## 3. Recommended builds (ranked for a €0 solo builder)

| Rank | # | Build | Time to MVP | Why it's first |
|---|---|---|---|---|
| 1 | **#131** | Repair Diagnostic Wizard | 1–2 weeks | Pure content + logic + SEO. Nothing to host beyond static pages. Fastest to something real. |
| 2 | **#27** | Public-Domain Songbook Generator | 2–4 weeks | Legally bulletproof content engine; builds a library asset that compounds. |
| 3 | **#89** | Generated Backing Tracks (procedural) | 4–8 weeks | The flagship: high user value, zero licenses (code + CC0 soundfonts), user owns output. |
| 4 | **#219** | AI-Tab Fidelity Checker | 2–4 weeks | Rides the AI-transcription wave; validator position in a crowded category. |
| 5 | **#194** | Guitar → Tab on Own Takes | 3–6 weeks | Free model (Basic Pitch) + playability logic; aimed at the user's own recordings. |

Others strong and ready to spec on request: #49 (on-instrument ear trainer), #3/#4 (practice logger + Wrapped), #209 (NAM capture optimizer), #79 (setup wizard), #118 (self-grading homework, B2B).

---

## 4. Build specs — the top three, ready to execute

### 4.1 — #131 Repair Diagnostic Wizard

**Goal:** describe a guitar problem in plain words → get ranked likely causes, a fix order, and measurement instructions. Fully static, no backend.

- **MVP scope (v1):** 6 symptom trees shipped — fret buzz, high action, tuning instability, dead/weak note, hum/noise, intonation off. Each tree: symptom qualifiers (which string/fret/when), ranked causes, checks with simple measurements (credit-card feeler gauge, ruler, phone camera), fix instructions, "when to take it to a luthier".
- **Stack:** static HTML/CSS/JS (or SvelteKit static export). Content as JSON data files so trees are edit-able without code. Deploy: GitHub Pages / Cloudflare Pages (free).
- **File layout:** `/data/trees/*.json`, `/src` UI, `/tests` (see below), `LICENSES.txt`.
- **Milestones:** (1) data schema + 1 tree end-to-end, (2) 6 trees + measurement diagrams (SVG), (3) printable fix sheets, (4) feedback widget (mailto form — free), (5) deploy.
- **Acceptance:** a non-guitar-savvy person can go from symptom to a ranked cause list in under 90 seconds; every tree has at least 3 causes with distinct checks; no dead ends.
- **Pitfalls:** don't over-branch (start linear, add depth later); keep language non-technical; cite no copyrighted forum text.
- **Later (money, optional):** affiliate links to parts/tools, luthier lead-gen, Pro saved instrument profiles.

### 4.2 — #27 Public-Domain Songbook Generator

**Goal:** turn public-domain melodies into clean, playable guitar arrangements (tab + notation + audio) automatically.

- **MVP scope (v1):** one source format in (MusicXML or ABC), arrangement for one difficulty (melody + simple bass), tab rendering + playback, batch export to PDF + MIDI. Start with 20 tunes (folk/hymns/Christmas).
- **Stack:** Python pipeline (music21 or ABC parsing) → arrangement rules (key/difficulty constrained) → alphaTab (MPL-2.0) for tab rendering/playback in a static web viewer → FluidSynth + CC0 soundfont for offline audio render. All local/free.
- **Milestones:** (1) parse 1 tune → melody tab, (2) arrangement rule set + difficulty levels, (3) batch pipeline + static viewer, (4) 50-tune library published, (5) generator exposed (upload a PD file → get arrangement).
- **Acceptance:** generated arrangements are playable by a beginner (open position where possible), tab and audio agree, every tune traces to a PD source with date evidence in `LICENSES.txt`.
- **Pitfalls:** verify PD status per country (use pre-1929 sources); avoid trademarks in names; keep an attribution/source column for every tune.
- **Later:** print-on-demand songbooks, teacher packs, custom arrangement tiers.

### 4.3 — #89 Generated Backing Tracks (procedural)

**Goal:** chord chart in → drums + bass + keys out, in a chosen style/tempo/feel. User owns output. No AI cloud, no licenses.

- **MVP scope (v1):** one style (pop ballad or slow blues), text chord input (e.g. `| C | Am | F | G |`), tempo + feel (straight/swing), count-in, loop, export WAV/MIDI. Drums via sample-free synthesis or CC0 samples; bass/keys via FluidSynth soundfont.
- **Stack:** Web Audio API (AudioWorklet scheduling, not setInterval) or a desktop build later; a small pattern engine with styles as JSON data; ChordPro parsing for chords; FluidSynth + CC0 SF2 for melodic parts. Runs fully client-side → free hosting works.
- **Milestones:** (1) metronome-grade timing engine + drum pattern, (2) bass following chord roots, (3) second style + fills + sections (verse/chorus), (4) keys/pad layer, (5) export + shareable link (URL-encoded chart).
- **Acceptance:** plays a 12-bar form at any tempo 60–200 with no drift over 5 minutes; output WAV imports cleanly into a DAW; user can hear their own chart back in under 10 seconds.
- **Pitfalls:** audio timing must be sample-accurate (schedule ahead); humanize velocity/timing so it isn't robotic; keep everything deterministic from the URL so users can share songs.
- **Later:** style packs, teacher/school licenses, desktop app for offline.

### 4.4 — Generic spec template (for any other number)

When a build is chosen, fill this in before writing code:

1. **One sentence:** *[who]* can now *[do what]* in *[how long]* instead of *[current painful way]*.
2. **MVP scope:** the narrowest slice that delivers that sentence with hardcoded/uploaded input. No accounts. No landing page.
3. **Stack mapping:** which €0-stack tools cover each piece (see §5).
4. **File layout + LICENSES.txt.**
5. **Milestones:** 4–6 checkpoints, each independently demoable.
6. **Acceptance criteria:** measurable, user-visible.
7. **Pitfalls:** known traps specific to this idea (check `ideas.html` and the part docs).
8. **Two-week demo plan:** what exists at the end of week one; what a stranger can do with it.

---

## 5. The €0 stack (condensed)

- **Code:** VS Code · Git + GitHub (free CI on public repos) · Python / TypeScript · SvelteKit or plain Vite.
- **App shape:** PWA / static web first (installable, offline); desktop wrapper later if needed for audio latency or file access.
- **Audio:** Web Audio API + AudioWorklet · Tone.js · alphaTab (tabs, MPL-2.0) · VexFlow (notation) · Tonal.js (theory) · FluidSynth + CC0 soundfonts · Basic Pitch (transcription, Apache-2.0) · Demucs (stems, MIT, local CPU) · YIN/CREPE (pitch).
- **Amp/plugin side:** NAM (MIT, CPU inference) · TONE3000 free trainer + free plugin · iPlug2 (MIT) / DPF (ISC) · VST3 + CLAP + LV2.
- **Backend (only if unavoidable):** Cloudflare Pages/Workers, Supabase/Neon/Turso, R2/B2 — all free tiers. Prefer none: local-first beats cloud.
- **Design:** Figma free, Inkscape, Inter font (OFL).
- **Free-tier rules:** local-first > cloud · static > server · on-device > API · PWA > native · one free tier per layer, swappable.

## 6. Conventions & quality bar

- **LICENSES.txt** in every project: one line per asset (name, source, licence, date).
- **Reproducible:** one command to run locally (`npm run dev` / `python -m ...`), documented in README.
- **No tracking, no ads, no accounts** unless the idea requires them.
- **Audio timing:** never `setInterval` for musical timing — schedule ahead in the audio thread.
- **Accessibility:** keyboard navigable, readable at 200% zoom.
- **Ship small:** a working narrow tool beats a half-built wide one. Week-one demo to one real user (the owner counts).

## 7. What the new session should do first

1. Read this file + `ideas.html` (skim the deep dives).
2. Confirm the pick (or use the "help me choose" prompt).
3. Fill the template in §4.4 for the chosen idea.
4. Scaffold the project, set up LICENSES.txt + README, get a hello-world of the *core technical risk* running (e.g., for #89: a click track with perfect timing; for #194: Basic Pitch on one recording).
5. Only then build UI. MVP in the narrowest slice; iterate.

## 8. Do-nots (so the new session doesn't re-litigate)

- Don't propose paid tools, cloud GPU, licensed sample libraries, or app-store distribution.
- Don't build: another amp sim, tuner, metronome, generic IR loader, generic AI transcriber, or a capture library — all saturated (see `part4-plugins-deep.md` §"Red oceans").
- Don't resurrect the parked 20 (hardware, escrow, print, licensed-content hosting) unless money exists.
- Don't worry about commercial licensing — this is a personal build.

---

*Compiled 29 Sep 2026 from the four-pass research in this folder. The bank: 236 ideas invented → 20 parked for budget → 216 live. Everything here is free to build and free to run.*
