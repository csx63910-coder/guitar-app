# 🚀 Kickoff Prompts — paste into the new session

How to use: attach (or paste) `ideas.html` + `HANDOFF.md`, then paste ONE of the prompts below. Pick the variant that matches what you want the new session to do.

---

## A. Pick a build (variant for each top choice)

### A1 — #131 Repair Diagnostic Wizard

> You are starting a new build for me. Attached: HANDOFF.md (build brief) and ideas.html (the idea bank). Read the brief first, then build **idea #131 — the Repair Diagnostic Wizard** exactly as specified in §4.1 of the handoff.
>
> Constraints: €0 budget (free tools, free hosting, no paid anything), personal use, static site with no backend, content as editable JSON data files.
>
> Start now: (1) propose the symptom-tree JSON schema, (2) scaffold the project (static SvelteKit or plain HTML/JS), (3) implement ONE full tree end-to-end (fret buzz) as the working proof, (4) then tell me what you'll add next. Ship something runnable in this first response — a minimal page that walks the buzz tree — not a plan.

### A2 — #27 Public-Domain Songbook Generator

> You are starting a new build for me. Attached: HANDOFF.md and ideas.html. Read the brief, then build **idea #27 — the Public-Domain Songbook Generator** per §4.2 of the handoff.
>
> Constraints: €0, personal use, everything runs locally/free: Python pipeline for arrangement, alphaTab for tab rendering (MPL-2.0), FluidSynth + a CC0 soundfont for audio. Start with ONE public-domain tune (pick a well-known traditional melody) rendered as melody tab + playback.
>
> Start now: (1) choose the input format (ABC or MusicXML) and justify in one line, (2) scaffold the pipeline, (3) produce the first end-to-end arrangement of one tune (tab + WAV) — working code, not a plan, (4) list the next three tunes to add.

### A3 — #89 Generated Backing Tracks

> You are starting a new build for me. Attached: HANDOFF.md and ideas.html. Read the brief, then build **idea #89 — Generated Backing Tracks (procedural)** per §4.3 of the handoff.
>
> Constraints: €0, personal use, fully client-side (Web Audio API + AudioWorklet; sample-accurate scheduling, never setInterval), free CC0 soundfonts for melodic parts, no cloud AI, no licensed content. The user owns the output.
>
> Start now: (1) scaffold a web app with the timing engine (a click that stays rock-solid at any tempo), (2) add a drum pattern for one style, (3) accept a text chord chart (`| C | Am | F | G |`) and make a bass line follow it, (4) return a runnable demo I can play with, then outline the next milestones. Working prototype first, polish later.

### A4 — #219 AI-Tab Fidelity Checker

> You are starting a new build for me. Attached: HANDOFF.md and ideas.html. Read the brief, then build **idea #219 — the AI-Tab Fidelity Checker** (spec: see the deep dive in ideas.html).
>
> Constraints: €0, personal use, processes the user's own files locally (no hosting of copyrighted material), free tools only (Basic Pitch for note extraction, alphaTab for tab display).
>
> Start now: (1) define the scoring model — accuracy (note agreement vs. audio) and playability (fret spans, position jumps), (2) scaffold a local app that takes (audio file, tab file) and outputs a per-bar score heatmap, (3) implement the simplest version for monophonic lines, (4) show me a working run on a test file, then propose the chord/polyphonic upgrade path.

### A5 — #194 Guitar → Tab on Own Takes

> You are starting a new build for me. Attached: HANDOFF.md and ideas.html. Read the brief, then build **idea #194 — Guitar → Tab on your own takes**.
>
> Constraints: €0, personal use, local processing, free model: Spotify Basic Pitch (Apache-2.0) for note extraction; your job is the guitar-logic layer (position/fingering inference) + alphaTab rendering + MIDI export.
>
> Start now: (1) get Basic Pitch running on a small test recording (or a synthesized guitar line) locally, (2) build the note → fret-position inference for a single-string melody, (3) render the result as tab with alphaTab, (4) return a working pipeline I can run on my own recordings, then plan polyphony.

---

## B. Help me choose (if you want the session to advise first)

> You are helping me choose what to build, then building it. Attached: HANDOFF.md (build brief) and ideas.html (216 live ideas, all €0-buildable, personal use).
>
> Read the brief first. Then: (1) ask me 5 sharp questions about my interests, skills, and how I actually practise/play; (2) recommend the 3 best ideas for ME from the bank, with one paragraph each on why; (3) wait for my choice; (4) then follow the generic spec template in §4.4 of the handoff and start the build with working code in the same session.
>
> Don't recommend: anything in the parked list, anything that needs money, another amp sim/tuner/metronome, or anything requiring a server.

---

## C. No files attached? Paste this mini-brief first

> **Context for you:** I want to build a piece of guitar software for personal use with a €0 budget. Hard rules: free/open-source tools only, free-tier hosting or local-first (no servers if avoidable), personal-use licences OK, any music files I own are fair game, no piracy. Everything runs on my PC (web app and/or desktop app). I have a bank of 216 researched, zero-budget-friendly ideas (learning tools, tabs, ear training, tone tools, backing tracks, plugins, luthier tools, practice analytics) with 12 deep dives and build specs for the top ones. Full brief and catalog are in `HANDOFF.md` and `ideas.html` in my workspace — read them if you can access the workspace; otherwise ask me to paste the relevant spec.
>
> I want to build: **[IDEA NUMBER / NAME]**. Start with the working core (the riskiest technical piece) before any UI, use only free tools, keep everything local-first, and show me runnable code in your first response.

---

## D. Quick variants for other strong picks

| Idea | One-line kickoff addition |
|---|---|
| **#49** On-instrument ear trainer | "Web app; Web Audio playback + YIN pitch detection on the mic; difficulty ladder from single notes to 2-bar phrases; score pitch and timing." |
| **#3/#4** Practice logger + Wrapped | "Detect playing via audio activity on mic (avoid false positives from media), log sessions locally in IndexedDB, generate a shareable recap page." |
| **#209** NAM capture optimizer | "Desktop/CLI; parse .nam files (MIT format), downscale to nano/feather for target devices, report fidelity vs. original; CPU-only, no GPU." |
| **#79** Setup wizard | "Static/offline web app; guided truss-rod/action/intonation flow; measurements via phone camera + reference card; printable setup sheet; store per-guitar history locally." |
| **#118** Self-grading homework (B2B) | "Browser recording via MediaRecorder; score timing vs. click + chord-change accuracy; teacher dashboard on a free tier; invoices handled manually at first." |

---

*Reminder for the new session: read `HANDOFF.md` §1 (constraints) and §6 (quality bar) before writing any code. Ship the narrowest runnable slice first.*
